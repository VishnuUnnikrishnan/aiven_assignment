# Avien Assignment: Page Up

## Summary:
This application checks if a page is up or not and stores that information for future use. 

## Functional Description

## Assumptions

The following assumptions were made during the development of the code.

1. The database and database tables already exist and do not need to be set up.
2. The Kafka instance and topic have already been set up.

## Usage

